export interface productModel {
  _id?: any;
  image?: any;
  name?: any;
  category?: any;
  stock?: any;
  price?: any;
  orders?: any;
  rating?: any;
  publishedDate?: any;
  time?: any;
  status?: any;
}
