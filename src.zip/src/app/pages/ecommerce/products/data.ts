
const Products = [
  {
    image: 'assets/images/products/img-1.png',
    name: 'Half Sleeve Round Neck T-Shirts',
    category: 'Clothes',
    stock: '12',
    price: '115.00',
    orders: '48',
    rating: '4.2',
    publishedDate: '12 Oct, 2021',
    time: '10:05 AM',
  }
];

export { Products };
