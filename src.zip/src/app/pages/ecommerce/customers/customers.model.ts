export interface customerModel {
  _id:any;
  customer: string;
  email: string;
  phone: string;
  date: string;
  status: string;
  statusClass: string;
  isSelected?:any;
}
