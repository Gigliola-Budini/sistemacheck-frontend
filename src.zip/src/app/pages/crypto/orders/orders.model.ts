export interface OrdersModel {
  date: string;
  time: string;
  img: string;
  coinName: string;
  type: any;
  typeClass: string;
  quantity: string;
  orderValue: string;
  avgPrice: string;
  price: string;
  status: string;
  statusClass: string;
}

