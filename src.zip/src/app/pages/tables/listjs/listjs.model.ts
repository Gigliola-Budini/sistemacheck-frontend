export interface ListJsModel {
  id: any;
  customer_name: string;
  email: string;
  phone: string;
  date: string;
  status: string;
  status_color: string;
  isSelected?:any;
}
